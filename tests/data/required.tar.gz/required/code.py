
import os

def function(one_arg):
    "Docstring."
    pass

