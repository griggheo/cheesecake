
# There's not docstring for this module

def function():
    "Documented!"
    pass
