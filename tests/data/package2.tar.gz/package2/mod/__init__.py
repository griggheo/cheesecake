#
# No docstring but a function
#

def fun():
    "Documented function."
    pass
