
from types import ComplexType

class Class(ComplexType):
    "Comment."
    def method(self):
        pass
