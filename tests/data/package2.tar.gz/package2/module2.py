"""Module with docstring.

It has 1 class with 2 methods, 2 functions and 3 other global objects.
"""

class Class(object):
    "Class with documentation."
    def method(self):
        # No docstring
        pass

    def method2(self, *args, **kwds):
        "*reST* docstring."
        pass


def function():
    return True


number = 42
string = "Forty two."
function2 = lambda x: x + 1


def function3():
    """
    Documented function.
    """
    pass
