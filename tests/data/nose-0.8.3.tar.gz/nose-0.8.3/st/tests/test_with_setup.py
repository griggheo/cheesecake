from selftest import ExpectedFail
from nose.core import with_setup

Track = {}

def a_setup():
    Track['a_setup'] = True
def a_teardown():
    Track['a_teardown'] = True
 
def test_with_setup():
    assert Track.has_key('a_setup')
test_with_setup = with_setup(a_setup, a_teardown)(test_with_setup)

def test_post_with_setup():
    global Track
    assert Track.has_key('a_teardown')
    Track = {}

def test_atomic_with_setup():
    assert ExpectedFail
test_atomic_with_setup = with_setup(a_setup, a_teardown)(test_atomic_with_setup)

def test_post_atomic_with_setup():
    # need to make sure that even in exception
    # with_setup ensures teardown function is called
    assert Track.has_key('a_teardown')
