count = {'setup':0,
         'test':0,
         'teardown':0}

def setup(module):
    assert count['setup'] == 0
    assert count['test'] == 0
    assert count['teardown'] == 0
    module.count['setup'] += 1

def test():
    assert count['setup'] == 1
    assert count['teardown'] == 0
    assert count['test'] == 0
    count['test'] = 1
    
def teardown(module):
    module.count['teardown'] += 1
    assert module.count['setup'] == 1
    assert module.count['test'] == 1
    assert module.count['teardown'] == 1
