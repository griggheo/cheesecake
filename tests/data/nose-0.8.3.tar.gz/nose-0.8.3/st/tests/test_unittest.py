from selftest import ExpectedFail
import unittest

class TestBasic(unittest.TestCase):

    state = 0
    
    def setUp(self):
        self.state = 1
        print "setup!"

    def tearDown(self):
        self.state = 0

    def testPasses(self):
        pass
        
    def testCapture(self):
        print "Capture this"
        assert ExpectedFail, "setup!\nCapture this"
