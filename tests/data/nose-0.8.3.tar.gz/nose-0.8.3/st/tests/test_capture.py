from selftest import ExpectedFail
from unittest import TestCase

def test_that_fails():
    print "This is some captured output"
    assert ExpectedFail, "This is some captured output"

class Capturer(TestCase):

    def setUp(self):
        print "setup"

    def test_nothing(self):
        print "test"
        assert ExpectedFail, "setup\ntest"

    def tearDown(self):
        print "teardown -- this should not be seen"
