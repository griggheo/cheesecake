def test_basic():
    """a test function"""    
    assert True

class TestSomething:
    def test_method(self):
        """a test method in a test class"""
        assert True

    def test_method_two(self):
        assert True

class TestClassWithLabel:
    """Labeled test class"""
    def test_method(self):
        assert True
        
