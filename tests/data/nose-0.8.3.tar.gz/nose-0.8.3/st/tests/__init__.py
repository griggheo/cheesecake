Tracker = []

def setup_package():
    Tracker.append("setting up package")
    assert Tracker == ['setting up package']
    
def teardown_package():
    Tracker.append("tearing down package")
    assert Tracker == ['setting up package',
                       'tearing down package']
