def setup():
    #raise Exception("setup was called")
    pass

def teardown():
    #raise Exception("teardown was called")
    pass
