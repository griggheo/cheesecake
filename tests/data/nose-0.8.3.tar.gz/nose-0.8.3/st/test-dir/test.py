from selftest import ExpectedFail

def test():
    assert True, "Hello"

def test_that_fails_too():
    assert ExpectedFail
