was_setup = False
was_torn_down = False

def setup_module(module):
    module.was_setup = True

def teardown_module(module):
    module.was_torn_down = True

def test():
    assert was_setup
