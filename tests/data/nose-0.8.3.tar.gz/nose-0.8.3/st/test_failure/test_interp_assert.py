from unittest import TestCase

def test_simple_assert():
    assert False, "assert False"

def test_assert_expression():
    a = 2
    assert a == 4, "assert 2 is 4"

def test_raise_assert():
    b = ['1','2','3']
    if not b == 'foo': raise AssertionError, "a message"

def test_unicode_assert():
    ustr = u'\240 is a unicode char over 128'
    assert ustr < 'a', 'Unicode error'

def test_unicode_in_junk():
    ublob = {'a':[u'Andr\202 3000',200],
             u'\240dre':'stuff'}
    assert ublob.has_key('b'), 'No b in blob'
    
class FunkyColdMedina(TestCase):

    def testFailUnless(self):
        c = 'foo'
        self.failUnless(c.find('k') > 0,'Needs a k')
