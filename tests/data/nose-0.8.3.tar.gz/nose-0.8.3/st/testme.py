def test_me_once():
    pass
