def test():
    """This is a test in stpackage/test-dir"""
    # raise "HELL"
    pass
