from stpackage import a_function

def deep_doc():
    """Testing that deeply-nested doctests are found, and that intra-package
    imports work with nose.importer
    
    >>> type(a_function)
    <type 'function'>
    """
    a_function()
