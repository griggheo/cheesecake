print "YO YO YO!"

def a_function():
    """Sample doctest

    >>> a_function()
    ['a', 'b', 'c']
    """
    return ['a','b','c']

def a_failing_function():
    """Sample failing doctest

    Notice that output capture doesn't work in doctests.
    
    >>> a_failing_function()
    This is the sort of test that ought to fail
    >>> 1 + 1
    9
    """
    print "This is the sort of test that ought to fail"
    
def test_not_a_test():
    raise Exception("This test should not be run, it is not in a"
                    "test module")

