"""Implements an importer that looks only in specific path (ignoring
sys.path), and uses a per-path cache in addition to sys.odules

Test modules frequently have the same tail name, which can result in false
positives from sys.modules caching, so the importer removes from sys.modules
any module that matches testMatch.
"""

from imp import find_module, load_module, acquire_lock, release_lock
from nose.util import msg, Config

import os
import sys

_modules = {}

def _import(name, path):
    """Import a module *only* from path, ignoring sys.path and possibly
    reloading if the version in sys.modules is not the one we want.
    """
    cache = _modules.setdefault(':'.join(path), {})

    # quick exit for fully cached names
    if cache.has_key(name):
        return cache[name]
    
    parts = name.split('.')
    fqname = ''
    mod = parent = fh = None
    
    for part in parts:
        if fqname == '':
            fqname = part
        else:
            fqname = "%s.%s" % (fqname, part)

        if cache.has_key(fqname):
            mod = cache[fqname]
        else:
            try:
                acquire_lock()                                
                fh, filename, desc = find_module(part, path)
                old = sys.modules.get(fqname)
                if (old):
                    # test modules frequently have name overlap; make sure
                    # we get a fresh copy of anything we are trying to load
                    # from a new path
                    if hasattr(old,'__path__'):
                        old_path = os.path.normpath(old.__path__[0])
                        old_ext = None
                    else:
                        old_norm = os.path.normpath(old.__file__)
                        old_path, old_ext = os.path.splitext(old_norm)
                    new_norm = os.path.normpath(filename)
                    new_path, new_ext = os.path.splitext(new_norm)
                    if old_path == new_path:
                        msg("module already %s loaded old: %s %s new: %s %s"
                            % (fqname, old_path, old_ext, new_path, new_ext),
                            6)
                        cache[fqname] = mod = old
                        continue
                    else:
                        del sys.modules[fqname]
                mod = load_module(fqname, fh, filename, desc)
                cache[fqname] = mod
            finally:
                if fh:
                    fh.close()
                release_lock()
        if parent:
            setattr(parent, part, mod)
        if hasattr(mod, '__path__'):
            path = mod.__path__
        parent = mod
    return mod
