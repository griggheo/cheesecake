"""Implements utility functions and classes used by nose.core
"""
import os
import re
import sys

try:
    from cStringIO import StringIO
except ImportError:
    from StringIO import StringIO

    
def absdir(path):
    """Return absolute, normalized path to directory, if it exists; None
    otherwise.
    """
    if not path.startswith(os.path.sep):
        path = os.path.normpath(os.path.abspath(os.path.join(os.getcwd(),
                                                             path)))
    if path is None or not os.path.isdir(path):
        return None
    return path


def absfile(path, where=None):
    """Return absolute, normalized path to file (optionally in directory
    where), or None if the file can't be found either in where or the current
    working directory.
    """
    orig = path
    if where is None:
        where = os.getcwd()
    if path[0] != os.path.sep:
        path = os.path.normpath(os.path.abspath(os.path.join(where, path)))
    if path is None or not os.path.exists(path):
        if where != os.getcwd():
            # try the cwd instead
            path = os.path.normpath(os.path.abspath(os.path.join(os.getcwd(),
                                                                 orig)))
    if path is None or not os.path.exists(path):
        return None
    if os.path.isdir(path):
        # might want in __init__.py from pacakge
        init = os.path.join(path,'__init__.py')
        if os.path.isfile(init):
            return init
    elif os.path.isfile(path):
        return path
    return None

    
def msg(message, min_verbosity=0, stream=None):
    """Output a status message, if configured verbosity is greater than
    the minimum verbosity rating of the message.
    """
    if Config.verbosity > min_verbosity:
        if stream is None:
            stream = sys.stderr
        stream.write("  " * (min_verbosity-1))
        stream.write(message)
        stream.write("\n")

        
class _Capture(object):
    """Output capture handler
    """
    def __init__(self):
        self.buffer = None
        self.orig_stdout = sys.stdout

    def begin(self):
        """Start capturing output
        """
        self.buffer = StringIO()
        sys.stdout = self.buffer
        msg("begin capture %s" % sys.stdout, 5)

    def captured(self):
        """Return buffer of captured output
        """
        if self.buffer is not None:
            return self.buffer.getvalue()
        
    def __call__(self):
        self.begin()

    def end(self):
        """Restore system stdout
        """
        sys.stdout = self.orig_stdout
            
Capture = _Capture()


class _Config(object):
    """nose configuration. For internal use only.
    """
    testMatch = re.compile(r'(?:^|[\b_\.-])[Tt]est')
    capture = True
    coverage = False
    cover_modules = {}
    detailed_errors = False
    file_only = None
    include = None
    exclude = None
    verbosity = 1
    where = None

    def __str__(self):
        return str({
                'testMatch': self.testMatch,
                'detailed_errors': self.detailed_errors,
                'include': self.include,
                'exclude': self.exclude,
                'capture': self.capture,
                'verbosity': self.verbosity,
                'where': self.where })

    def wantTestsFromFile(self, file):
        if self.file_only is None:
            return True
        else:
            # file extension on one or the other might be .py or py[c|o]
            want_root, want_ext = os.path.splitext(self.file_only)
            candidate_root, candidate_ext = os.path.splitext(file)
            if candidate_root == want_root:
                if (candidate_ext == want_ext or
                    (candidate_ext.startswith('.py') and
                     want_ext.startswith('.py'))):
                    return True
            msg("Skipping tests in '%s' (want '%s')" %
                (file, self.file_only), 3)
            return False
        
    def wantTest(self, name, test_case=False, file=None):
        """Detemine whether a given name is a wanted test
        """
        # testcase subclasses get a pass on matching testMatch
        msg("is %s (%s) (%s) a wanted test?" % (name, test_case, file), 5)
        if (file is not None
            and not self.wantTestsFromFile(file)):
            return False
        if not test_case and not self.testMatch.search(name):
            msg("%s does not match testMatch" % name, 5)
            return False
        if self.include and not self.include.search(name):
            msg("%s does not match include" % name, 5)
            return False
        if self.exclude and self.exclude.search(name):
            msg("%s matches exclude" % name, 5)
            return False
        msg("%s is a test" % name, 5)
        return True
    
Config = _Config()


def start_coverage():
    """Start measuring code coverage"""
    import atexit
    import coverage
    coverage.start()
    atexit.register(coverage_report)

    
def coverage_report():
    """End code coverage and output report"""
    import coverage
    coverage.stop()
    coverage.report(Config.cover_modules.values(), file=sys.stderr)
        
