"""Implements core nose test discovery functions.
"""
import os
import re
import sys
import types
import unittest
from doctest import DocTestSuite
from optparse import OptionParser

import nose.importer
from nose.util import absdir, absfile, Capture, Config, msg, start_coverage

class TestCase(unittest.TestCase):
    """Adds stdout capture to unittest.TestCase
    """
    capturing = False

    def __call__(self, *args, **kwds):
        """< 2.4 compatibility"""
        self.run(*args, **kwds)
    
    def run(self, result=None):
        """Run tests, capturing stdout
        """
        if Config.capture:
            self.startCapture()

        #
        # In unittest versions with python 2.3 (and lower?), the call/run
        # logic is reversed, with the meat of the test running in __call__
        #
        if unittest.__version__ <= '1.46':
            super(TestCase, self).__call__(result)
        else:
            super(TestCase, self).run(result)
            
    def startCapture(self):
        """Start capturing stdout
        """
        Capture()

        
class Wrap(TestCase):
    """Wrapper for legacy testcases. Allows unittest.TestCase instances
    that are not also nose.TestCase instances to run with output
    capture.
    """
    def __init__(self, testCase):
        self.testCase = testCase
        
    def __str__(self):
        return str(self.testCase)
    
    def runTest(self, result):
        """Run wrapped test case
        """
        self.testCase(result)

    def run(self, result=None):
        """Run the test, starting output capture beforehand if desired.
        """
        if result is None:
            result = self.defaultTestResult()
        if Config.capture:
            self.startCapture()
        self.runTest(result)


class FunctionTestCase(TestCase):
    """TestCase wrapper for functional tests.

    Don't use this class directly; it is used internally in nose to
    create test cases for functional tests.
    
    This class is very similar to unittest.FunctionTestCase, with a few
    extensions:
      * It descends from nose.TestCase, and so provides output
        capture
      * It allows setup and teardown functions to be defined as attributes
        of the test function. A convenient way to set this up is via the
        provided with_setup decorator:

        def setup_func():
            # ...

        def teardown_func():
            # ...
        
        @with_setup(setup_func, teardown_func)        
        def test_something():
            # ...

    """
    def __init__(self, testFunc, setUp=None, tearDown=None, description=None,
                 from_directory=None):
        TestCase.__init__(self)
        self.testFunc = testFunc
        self.setUpFunc = setUp
        self.tearDownFunc = tearDown
        self.description = description
        self.from_directory = from_directory

    def id(self):
        name = self.testFunc.__name__
        if self.from_directory is None:
            return name
        else:
            return "%s: %s" % (self.from_directory, name)
    
    def runTest(self):
        self.testFunc()
        
    def setUp(self):
        """Run any setup function attached to the test function
        """
        if self.setUpFunc:
            self.setUpFunc()
        else:
            names = ('setup', 'setUp', 'setUpFunc')
            try_run(self.testFunc, names)

    def tearDown(self):
        """Run any teardown function attached to the test function
        """
        if self.tearDownFunc:
            self.tearDownFunc()
        else:
            names = ('teardown', 'tearDown', 'tearDownFunc')
            try_run(self.testFunc, names)
        
    def __str__(self):
        name = "%s.%s" % (self.testFunc.__module__, self.testFunc.__name__)
        if self.from_directory is None:
            return name
        else:
            return "%s: %s" % (self.from_directory, name)
    __repr__ = __str__
    
    def shortDescription(self):
        pass # FIXME

class MethodTestCase(TestCase):
    """Test case that wraps one method in a test class.
    """
    def __init__(self, klass, method):
        self.klass = klass
        self.method = method
        self.testInstance = self.klass()
        self.testCase = getattr(self.testInstance, self.method)
        
        super(MethodTestCase, self).__init__()
        
    def __str__(self):
        return self.id()
        
    def id(self):
        return "%s.%s.%s" % (self.klass.__module__,
                             self.klass.__name__,
                             self.method)

    def setUp(self):
        """Run any setup method declared in the test class to which this
        method belongs
        """
        names = ('setup', 'setUp')
        try_run(self.testInstance, names)

    def runTest(self):
        self.testCase()
        
    def tearDown(self):
        """Run any teardown method declared in the test class to which
        this method belongs
        """
        if self.testInstance is not None:
            names = ('teardown', 'tearDown')
            try_run(self.testInstance, names)

    def shortDescription(self):
        if self.testCase.__doc__ is not None:            
            return '(%s.%s) "%s"' % (self.klass.__module__,
                                     self.klass.__name__,
                                     self.testCase.__doc__)
        return None
        
class TestLoader(unittest.TestLoader):
    """Discovery-based test loader. Loads tests from packages and modules
    (by name or reference) using TestPackage and TestModule.
    """

    def loadTestsFromClass(self, klass):
        """Load tests from a class that is not a TestCase subclass.

        Selects callable members that match testmatch, wraps each in
        MethodTestCase and returns.
        """
        entries = dir(klass)
        tests = []
        for item in entries:
            if callable(getattr(klass, item)) and Config.wantTest(item):
                tests.append(MethodTestCase(klass, item))
        return tests                             
    
    def loadTestsFromName(self, name, path=None):
        """Load tests from whatever loadable python thing is in the directory,
        package or or file name (optionally at path path)
        """
        msg("Load tests from %s at %s" % (name, path), 4)        
        test = name
        collector = TestModule

        if test.find('/') >= 0:
            head, test = os.path.split(test)
            if path is None:
                path = head
            else:
                path = os.path.join(path, head)
        if path is None:
            fullpath = os.path.abspath(test)
        else:
            fullpath = os.path.abspath(os.path.join(path, test))
        
        msg("Full path to %s is %s" % (name, fullpath), 4)
        if test.endswith('.py'):
            # trim the extension
            test = test[:-3]
        elif os.path.isdir(fullpath):
            init = os.path.join(fullpath, '__init__.py')
            if not os.path.exists(init):
                collector = TestDirectory
                    
        msg("test '%s' resolves to '%s' in '%s' (%s)"
            % (name, test, path, collector), 4)

        return collector(test, path)

    def loadTestsFromTestCase(self, testCaseClass):
        """Load tests from a TestCase subclass. Overrides superclass to
        wrap loaded test cases in Wrap, to enable output capture
        """
        suite = super(TestLoader, self).loadTestsFromTestCase(testCaseClass)

        # backwards compatibility; suites became iterable in 2.4
        if not hasattr(suite, '__iter__'):
            suite = iter(suite._tests)
        
        wrapped = []
        for test in suite:
            if not isinstance(test, TestCase):
                wrapped.append(Wrap(test))
            else:
                # no need to wrap instances of nose.TestCase
                wrapped.append(test)
        return wrapped
    
    def _import(self, name, path):
        """Import a name. Must be a normal python module name. Supplied
        path is prepended to sys.path for the duration of the method.
        """
        msg("Import %s from %s" % (name, path), 3)
        module = nose.importer._import(name, [path])
        if module and Config.coverage and not Config.wantTest(name):
            Config.cover_modules[module.__name__] = module
        return module
    
defaultTestLoader = TestLoader()


class TestCollector(unittest.TestSuite):
    """Discovery-based test suite.

    Unless told not to, the collector looks in the current directory for
    test packages, modules, or directories and creates test suites to run
    all tests in any found. A list of tests to run may also be specified.

    Test modules, packages or directories are:
      * Any directory with 'test' in the name (will be loaded as a test
        package if it contains an __init__.py file, otherwise as a test
        directory)
      * And file with 'test' in the name (will be loaded as a test module)
    """
    failureException = unittest.TestCase.failureException
    ignore = ['CVS']
    loader = defaultTestLoader
    
    def __init__(self, names=[], find=True, path=os.getcwd()):
        self.names = names
        self.find = find
        self.path = path

        # make sure the running dir is in sys.path so local imports
        # will work from tests dirs at same level as packages
        if not path in sys.path:
            sys.path.insert(0,path)
        
    def __call__(self, *args, **kwds):
        """For backwards compatibility. Between python 2.3 and 2.4
        unittest reversed its usage of __call__ and run(). nose expects
        the 2.4 implementation.
        """
        self.run(*args, **kwds)
        
    # FIXME
    def __repr__(self):
        return "collector in %s" % self.path
    __str__ = __repr__

    def collectTests(self):
        """Collect tests to run. This method is a generator.
        """
        for name in self.findTests():
            yield self.loader.loadTestsFromName(name, self.path)
            
    def exc_info(self):
        return sys.exc_info()

    def findTests(self):
        """Find tests in the target directory. Combines discovered tests
        with self.names to produce final list of tests to run.
        """
        if self.find:
            msg("Finding tests...", 2)
            names = self.findTestsIn(self.path)
            if self.names:
                for item in self.names:
                    if item not in names:
                        names.append(item)
        else:
            names = self.names
            
        msg("Tests to run: %s" % names, 2)
        return names

    def findTestsIn(self, dirname, include_packages=True,
                    deep=False, package=None):
        """Find tests in a directory.

        Tests are:
          - files that match testMatch
          - directories that match testMatch

        Recursion is limited to packages. Packages will be examined for
        sub-packages or directories or files that match testMatch, and any
        found at any level will be added as tests.
        """
        msg("  %s looking for tests in %s [%s]" %
            (self, dirname, package), 2)

        names = []
        # for dirpath, dirnames, filenames in os.walk(dirname):

        entries = os.listdir(dirname)
        for item in entries:
            msg("candidate %s in %s" % (item, dirname), 3)
            if item in self.ignore or item[0] == '.':
                continue
            path = os.path.join(dirname, item)
            if os.path.isfile(path):
                root, ext = os.path.splitext(item)
                if ext != '.py':
                    continue
                if Config.wantTest(root, file=path):
                    if package is None:
                        name = root
                    else:
                        name = "%s.%s" % (package, root)
                    msg("file %s in %s (%s) is a test" %
                        (item, dirname, name), 3)
                    names.append(name)
            elif os.path.isdir(path):
                is_package = os.path.exists(os.path.join(path,'__init__.py'))
                if Config.wantTest(item):
                    if package is None:
                        name = item
                    else:
                        if is_package:
                            name = "%s.%s" % (package, item)
                        else:
                            # can't load as n.n, must turn package name
                            # back into path parts
                            name = os.path.join(package.replace('.',
                                                                os.path.sep),
                                                item)
                    msg("dir %s in %s (%s) is a test dir" %
                        (item, dirname, name), 3)
                    names.append(name)
                elif is_package:
                    if package is None:
                        name = item
                    else:
                        name = "%s.%s" % (package, item)
                    msg("%s in %s (%s) is a package" %
                        (item, dirname, name), 3)
                    names.append(name)
            else:
                # ignore non-file, non-path item
                msg("%s in %s is neither file nor path" % (item, dirname), 3)
        if names:
            msg("Collected tests %s in %s" % (names, dirname), 2)
        return names
                            
    def run(self, result):
        """Collect and run all tests, running setup before and teardown
        after.
        """
        try:
            self.setUp()
        except KeyboardInterrupt:
            raise
        except:
            result.addError(self, self.exc_info())
            return
        for test in self.collectTests():
            msg("running test %s" % test, 4)
            if result.shouldStop:
                break
            test(result)
        try:
            self.tearDown()
        except KeyboardInterrupt:
            raise
        except:
            result.addError(self, self.exc_info())            
        return result

    def setUp(self):
        pass

    def shortDescription(self):
        return str(self) # FIXME

    def tearDown(self):
        pass


def collector():
    """TestSuite replacement entry point. Use anywhere you might use a
    unittest.TestSuite. Note: Except with testoob; currently (nose 0.8)
    testoob's test loading is not compatible with nose's collector
    implementation.
    """
    configure(env=os.environ)
    return TestCollector(find=Config.find, path=Config.where)


class TestDirectory(TestCollector):
    """Test collector that collects tests from python modules in a
    non-package directory.
    """
    def __init__(self, name, path):
        self.name = name
        self.path = path
        
    def __repr__(self):
        return "test directory %s" % self.path
    __str__ = __repr__
    
    def collectTests(self):
        """Collect tests from the directory
        """
        dirname = os.path.join(self.path, self.name)
        msg("Collect tests in directory %s" % dirname, 2)
        for test in self.findTestsIn(dirname):
            # otherwise names for tests in test dirs lack context
            test_module = self.loader.loadTestsFromName(test, dirname)
            test_module.from_directory = dirname
            yield test_module
        
class TestModule(TestCollector):
    """Test collector that collects tests from modules and packages.

    This collector collects module members that match the testMatch
    regular expression. For packages, it also collects any modules or
    packages found in the package __path__ that match testMatch. For
    modules that themselves do not match testMatch, the collector collects
    doctests instead of test functions.

    Before returning the first collected test, any defined setup method
    will be run. Packages may define setup, setUp, setup_package or
    setUpPackage, modules setup, setUp, setup_module or
    setUpModule. Likewise, teardown will be run if defined and if setup
    ran successfully; teardown methods follow the same naming rules as
    setup methods.
    """
    from_directory = None
    
    def __init__(self, module_name, path):
        self.module = None
        self.module_name = module_name
        self.path = path
        
    def __repr__(self):
        return "test module %s in %s" % (self.module_name, self.path)
    __str__ = __repr__
    
    def collectTests(self):
        """Collect tests in the module. Packages will also collect tests
        in the package directory. Non-test modules will collect only
        doctests.
        """
        if Config.wantTestsFromFile(self.module.__file__):
            # find tests defined in the module proper -- if it's a test module
            if Config.testMatch.search(self.module_name):
                for test in self.findTestsInModule(self.module):
                    yield test

            # find doctests for any and all modules
            try:
                doctests = DocTestSuite(self.module)
            except ValueError:
                pass
            else:
                # < 2.4 doctest (and unittest) suites don't have iterators
                if hasattr(doctests, '__iter__'):
                    doctest_suite = doctests
                else:                
                    doctest_suite = doctests._tests
                for test in doctest_suite:
                    yield Wrap(test)
                
        # recurse into any and all modules
        if hasattr(self.module, '__path__'):
            path = self.module.__path__[0]
            for test in self.findTestsIn(path,
                                         package=self.module.__name__):
                # setting the package prefix means that we're
                # loading from our own parent directory, since we're
                # loading xxx.yyy, not just yyy, so ask the loader
                # to load from self.path, not path
                yield self.loader.loadTestsFromName(test, self.path)
                
    def findTestsInModule(self, module, names=None):
        """Find functions and classes matching testMatch, as well as
        classes that descend from unittest.TestCase, return all found
        (properly wrapped) as tests.
        """
        def cmp_line(a, b):
            """Compare functions by their line numbers
            """
            a_ln = a.func_code.co_firstlineno
            b_ln = b.func_code.co_firstlineno
            return cmp(a_ln, b_ln)
        
        entries = dir(module)
        tests = []
        func_tests = []
        for item in entries:
            if names and not item in names:
                continue
            test = getattr(module, item)
            if isinstance(test, (type, types.ClassType)):
                if issubclass(test, unittest.TestCase):
                    [ tests.append(case) for case in
                      self.loader.loadTestsFromTestCase(test) ]
                elif Config.wantTest(item):
                    # test class; load methods 
                    [ tests.append(case) for case in
                      self.loader.loadTestsFromClass(test) ]
            elif callable(test) and Config.wantTest(item):
                # simple functional test
                func_tests.append(test)

        # run functional tests in the order in which they are defined
        func_tests.sort(cmp_line)
        [ tests.append(FunctionTestCase(test,
                                        from_directory=self.from_directory))
          for test in func_tests ]
        return tests
    
    def setUp(self):
        """Run any package or module setup function found. For packages, setup
        functions may be named 'setupPackage', 'setup_package', 'setUp',
        or 'setup'. For modules, setup functions may be named
        'setupModule', 'setup_module', 'setUp', or 'setup'. The setup
        function may optionally accept a single argument; in that case,
        the test package or module will be passed to the setup function.
        """

        # if module has been loaded from a test directory, unshift the
        # directory onto the top of sys.path, so that relative imports
        # will work in the imported module
        if self.from_directory is not None and self.path is not None:
            tmp = sys.path[:]
            sys.path.insert(0,self.path)
        try:
            self.module = self.loader._import(self.module_name, self.path)
        finally:
            if self.from_directory is not None and self.path is not None:
                sys.path = tmp
        if hasattr(self.module, '__path__'):
            names = ['setupPackage', 'setup_package']
        else:
            names = ['setupModule', 'setup_module']
        names += ['setUp', 'setup']
        try_run(self.module, names)
            
    def tearDown(self):
        """Run any package or module teardown function found. For packages,
        teardown functions may be named 'teardownPackage',
        'teardown_package' or 'teardown'. For modules, teardown functions
        may be named 'teardownModule', 'teardown_module' or
        'teardown'. The teardown function may optionally accept a single
        argument; in that case, the test package or module will be passed
        to the teardown function.

        The teardown function will be run only if any package or module
        setup function completed successfully.
        """        
        if hasattr(self.module, '__path__'):
            names = ['teardownPackage', 'teardown_package']
        else:
            names = ['teardownModule', 'teardown_module']
        names += ['tearDown', 'teardown']        
        try_run(self.module, names)


class TestProgram(unittest.TestProgram):
    """usage: %prog [options] [names]
    
    nose provides an alternate test discovery and running process for
    unittest, one that is intended to mimic the behavior of py.test as much as
    is reasonably possible without resorting to magic.
    
    nose collects tests automatically from python source files,
    directories and packages found in its working directory (which
    defaults to the current working directory). Any python source file,
    directory or package that matches nose.core.testMatch (by default:
    (?:^|[\b_\.-])[Tt]est) will be collected as a test (or source for
    collection of tests). In addition, all other packages found in the
    working directory are examined for python source files or directories
    that match nose.core.testMatch. Package discovery descends all the way
    down the tree, so package.tests and package.sub.tests and
    package.sub.sub2.tests will all be collected.
    
    Within a test directory or package, any python source file matching
    nose.core.testMatch will be examined for test cases. Within a test
    file, functions with 'test' in the name and TestCase subclasses (with
    any name) will be loaded and executed as tests. Functional tests may
    use the assert keyword or raise AssertionErrors to indicate test
    failure; TestCase subclasses may do the same or use the various
    TestCase methods available.
    
    Some options may also be set by env variables. For those options, the
    env variable appears in brackets at the end of the option
    description. Command line settings will override environment settings.
    
    Selecting Tests
    ---------------
    
    To prevent test discovery and run only the tests specified on the
    command line, use the -o switch::
    
      %prog -o only_test_this.py and_this

    To discover tests but run only those in a particular file or package, use
    the -f switch::

      %prog -f tests/only_these.py
  
    There is an important difference between running with -f and any other
    case where test files are specified on the command line, including
    -o. The -f switch processes the full test tree -- running setup and
    teardown for any package(s) that contain the selected test
    file. Without -f, nose will process only the file indicated, skipping
    setup and teardown of surrounding packages.

    You may also change the working directory where nose looks for tests,
    use the -w switch::

      %prog -w /path/to/tests

    Any of the above switches may be combined, for instance to run a
    particular test file in a test package in another location::

      %prog -w /path -o -f tests/only_these.py tests
      
    In this case, nose will run only the tests in the file only_these.py in
    /path/tests, and will run setup and teardown in /path/tests if /path/tests
    is a package and has defined setup or teardown methods.   
    """
    verbosity = 1
    
    def __init__(self, names=None, argv=None, testRunner=None,
                 testLoader=defaultTestLoader, env=None, stream=sys.stderr):
        self.names = names
        self.testRunner = testRunner
        self.testLoader = testLoader
        self.stream = stream
        self.success = False
        
        if argv is None:
            argv = sys.argv
        if env is None:
            env = os.environ
        self.parseArgs(argv, env)
        self.createTests()
        self.runTests()
        
    def parseArgs(self, argv, env):
        """Parse argv and env and configure running environment.
        """
        args = configure(argv, env)
        if args:
            self.names = args
        self.verbosity = Config.verbosity
        
        if Config.capture:
            Capture()

        if Config.capture or Config.detailed_errors:
            msg("* Installing nose exception patch", 3)
            # installs exception class that includes captured output
            # (and frame introspection for asserts) into exceptions
            import nose.exception
            nose.exception.install()
                
    def createTests(self):
        """Discover tests using TestCollector
        """
        self.test = TestCollector(self.names, Config.find, Config.where)

    def runTests(self):
        """Run Tests. Returns true on success, false on failure, and sets
        self.success to the same value.
        """
        if self.testRunner is None:
            self.testRunner = unittest.TextTestRunner(stream=self.stream,
                                                      verbosity=self.verbosity)
        result = self.testRunner.run(self.test)
        self.success = result.wasSuccessful()
        return self.success
        

def configure(argv=None, env=None):
    """Configure the nose running environment. Execute configure before
    collecting tests with nose.collector() to enable output capture and
    other features.
    """
    parser = OptionParser(TestProgram.__doc__)
    parser.add_option("-V","--version",action="store_true",
                      dest="version",default=False,
                      help="Output nose version and exit")
    parser.add_option("-v", "--verbose", action="count",
                      dest="verbosity", default=int(env.get('NOSE_VERBOSE', 1)),
                      help="Be more verbose. [NOSE_VERBOSE]")
    parser.add_option("-q", "--quiet", action="store_const",
                      const=0, dest="verbosity")
    parser.add_option("-w", "--where", action="store", dest="where",
                      default=env.get('NOSE_WHERE', os.getcwd()),
                      help="Look for tests in this directory [NOSE_WHERE]")
    parser.add_option("-f", "--file", action="store", dest="file_only",
                      default=env.get('NOSE_FILE', None),
                      help="Among found tests, run only those in this file")
    parser.add_option("-o", "--nodiscover", action="store_true",
                      dest="nodiscover", default=env.get('NOSE_NODISCOVER'),
                      help="Don't do any test discovery, load only "
                      "the tests indicated [NOSE_NODISCOVER]")
    parser.add_option("-e", "--exclude", action="store", dest="exclude",
                      default=env.get('NOSE_EXCLUDE'),
                      help="Don't run tests that match regular "
                      "expression [NOSE_EXCLUDE]")
    parser.add_option("-i", "--include", action="store", dest="include",
                      default=env.get('NOSE_INCLUDE'),
                      help="Run only tests that match regular "
                      "expression [NOSE_INCLUDE]")
    parser.add_option("-s", "--nocapture", action="store_true",
                      default=env.get('NOSE_NOCAPTURE'), dest="nocapture",
                      help="Don't capture stdout (any stdout output "
                      "will be printed immediately) [NOSE_NOCAPTURE]")
    parser.add_option("-d", "--detailed-errors", action="store_true",
                      default=env.get('NOSE_DETAILED_ERRORS'),
                      dest="detailed_errors", help="Add detail to error"
                      " output by attempting to evaluate failed"
                      " asserts [NOSE_DETAILED_ERRORS]")
    parser.add_option("-l", "--coverage", action="store_true",
                      default=env.get('NOSE_COVERAGE'),
                      help="Include coverage report in output "
                      "[NOSE_COVERAGE]")
    
    options, args = parser.parse_args(argv)

    if options.version:
        from nose import __version__
        print "%s version %s" % (os.path.basename(sys.argv[0])
                                 , __version__)
        sys.exit(0)
                                 
    # configuration works by setting class-level defaults
    # in Test and properties in runner and loader
    
    Config.capture = not options.nocapture
    Config.coverage = options.coverage
    Config.detailed_errors = options.detailed_errors
    Config.file_only = options.file_only
    Config.find = not options.nodiscover
    Config.verbosity = options.verbosity

    if options.where is not None:
        Config.where = absdir(options.where)
        if Config.where is None:
            raise Exception("Working directory %s not found, or "
                            "not a directory")
        msg("Looking for tests in %s" % Config.where, 1)
    if options.file_only is not None:
        Config.file_only = absfile(options.file_only, Config.where)
        if Config.file_only is None:
            raise Exception("File %s not found" % options.file_only)
        msg("Running tests in file %s only" % Config.file_only)
    if options.include:
        Config.include = re.compile(options.include)
        msg("Including tests matching %s" % options.include, 1)
    if options.exclude:
        Config.exclude = re.compile(options.exclude)
        msg("Excluding tests matching %s" % options.exclude, 1)

    if Config.coverage:
        start_coverage()
        
    try:
        return args[1:]
    except IndexError:
        return None


def main(*arg, **kw):
    """Collect and run test, returning success or failure
    """
    return TestProgram(*arg, **kw).success


def run_exit(*arg, **kw):
    """Run main() and exit with 0 on success or 1 on failure.
    """
    sys.exit(not main(*arg, **kw))

    
def try_run(obj, names):
    """Given a list of possible method names, try to run them with the
    provided object. Keep going until something works. Used to run
    setup/teardown methods for module, package, and function tests.
    """    
    for name in names:
        try:
            getattr(obj, name)()
            msg("call fixture %s.%s" % (obj.__name__, name), 5)
            return
        except TypeError:
            # py.test compatibility
            getattr(obj, name)(obj)
            msg("call fixture %s.%s(%s)" % (obj.__name__, name, obj), 5)
        except AttributeError:
            pass

        
def with_setup(setup=None, teardown=None):
    """Decorator to add setup and/or teardown methods to a test function

    @with_setup(setup, teardown)
    def test_something():
        # ...    
    """
    def decorate(func, setup=setup, teardown=teardown):
        if setup:
            func.setup = setup
        if teardown:
            func.teardown = teardown
        return func
    return decorate


if __name__ == '__main__':
    run_exit()
