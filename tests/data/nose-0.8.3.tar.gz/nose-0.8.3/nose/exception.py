"""Implements Exception extensions that support adding captured output and
detail about calling frame to exception messages
"""
import exceptions
import inspect
import os
import sys
import tokenize

try:
    from cStringIO import StringIO
except ImportError:
    from StringIO import StringIO

from nose.util import Config, Capture

_Exception = exceptions.Exception
_se_bases = exceptions.StandardError.__bases__
_installed = False

def install():
    """Install our base Exception class as the system-wide Exception and
    insert into StandardError.__bases__.
    """
    global _installed
    if not _installed:
        # On some systems (at least FreeBSD 4), if the standard exception
        # hierarchy is not in place at exit, a bus error can result
        import atexit
        atexit.register(remove)
        exceptions.Exception = Exception
        exceptions.StandardError.__bases__ = (Exception,)
        _installed = True
        
def remove():
    """Restore the builtin Exception and class hierarchy
    """
    global _installed
    if _installed:
        exceptions.Exception = _Exception
        exceptions.StandardError.__bases__ = _se_bases 
        _installed = False

class Exception(_Exception):    
    """Exception that includes captured output in its __str__. Also
    includes introspected assert frame if the exception is an
    AssertionError.

    For AssertionErrors, the error output will include an evaluated version of
    the assert expression in which names are replaced by their value in
    locals() or globals() in the frame in which the assert expression was
    evaluated.

    In other words if you have a test like::
    
      def test_integers():
          a = 2
          assert a == 4, "assert 2 is 4"

    You will get output something like::

      File "/path/to/file.py", line XX, in test_integers:
            assert a == 4, "assert 2 is 4"
      InspectAssertionError: assert 2 is 4
        >>  assert 2 == 4, "assert 2 is 4"
    """
    
    def __init__(self, *args):
        """Overrides Exception.__init__ to run frame inspection and start
        output capture.
        """
        _Exception.__init__(self, *args)
        
        # additional properties
        self.interp = None
        self.captured = None
        
        # it's very bad to raise an exception inside of Exception's __init__
        try:
            if Config.detailed_errors and isinstance(self, AssertionError):
                frame = sys._getframe(1)
                if frame is not None:
                    self.inspect(frame)
            if Config.capture:
                self.get_captured()
        except KeyboardInterrupt:
            os._exit(1)
        except Exception, e:
            sys.stderr.write("%s\n" % e)
            os._exit(1)

    def __str__(self):
        msg = _Exception.__str__(self)
        if self.interp is not None:
            msg = msg + '\n>>  ' + self.interp

        if self.captured is not None and len(self.captured):
            def ln(label):
                label_len = len(label) + 2
                chunk = (70 - label_len) / 2
                out = '%s %s %s' % ('-' * chunk, label, '-' * chunk)
                pad = 70 - len(out)
                if pad > 0:
                    out = out + ('-' * pad)
                return out
            msg = msg + '\n' + '\n'.join([ln('>> begin captured stdout <<'),
                                          self.captured,
                                          ln('>> end captured stdout <<')])
        msg = msg + '\n'        
        return msg

    def get_captured(self):
        """Get captured output from Capture object
        """
        self.captured = Capture.captured()

    def inspect(self, expr_frame):
        """Inspect exception calling frame, using Expander to fill in
        names with their repr()
        """
        frame_info = inspect.getframeinfo(expr_frame)
        try:
            if frame_info[3] is None:
                return
            source = StringIO(''.join(frame_info[3]))
        except (IOError, IndexError):
            return
        exp = Expander(expr_frame)
        tokenize.tokenize(source.readline, exp)        
        self.interp = exp.expanded_source    

    
class Expander:
    """Simple expression expander. Uses tokenize to find the names and
    expands any that can be looked up in the frame.
    """
    def __init__(self, frame):
        self.frame = frame
        self.locals = frame.f_locals
        self.globals = frame.f_globals
        self.lpos = None
        self.expanded_source = u''
         
    def __call__(self, ttype, tok, start, end, line):

        # TODO
        # deal with unicode properly
        
        # TODO
        # Dealing with instance members
        #   always keep the last thing seen  
        #   if the current token is a dot,
        #      get ready to getattr(lastthing, this thing) on the
        #      next call.
        
        if self.lpos is not None and start[1] > self.lpos:
            self.expanded_source += ' ' * (start[1]-self.lpos)
        self.lpos = end[1]
      
        if ttype == tokenize.INDENT:
            pass
        elif ttype == tokenize.NAME:
            try:
                val = self.locals[tok]
            except KeyError:
                try:
                    val = self.globals[tok]
                except KeyError:
                    val = tok
            # FIXME this is broken for some unicode strings
            self.expanded_source += unicode(val)
        else:
            self.expanded_source += tok

            
