#!/usr/bin/env python
import os
import re
import sys
import unittest

class TestNose(unittest.TestCase):    
    def setUp(self):
        # load results and expect file(s)
        self.results = file(local_file('selftest.result'),'r')
        self.log = file(local_file('selftest.log'),'r')

    def tearDown(self):
        self.results.close()
        self.log.close()
        
    def test01_NumTests(self):
        """Ran expected number of tests"""
        results = self.results.read()
        cm = re.compile(r'Ran (\d+) tests')
        m = cm.search(results)
        if not m:
            self.fail("No count found in results")
        else:
            self.assertEqual(m.groups()[0],'33')

    def test02_Results(self):
        """Test results were as expected"""
        results = self.results.read()
        expect = (
            (('py-test.test_something.test_one',),
             ('ok',)),
            (('py-test.test_something.test_two',),
             ('ok',)),
            (('stpackage.subpak.more.test.test_subpak_more_one',),
             ('ok',)),
            (('stpackage.subpak.tests.test_subak.test_subpackage',),
             ('ok',)),
            (('stpackage.tests.tests_from_package.test_top_level',),
             ('ok',)),
            (('Doctest: stpackage.a_failing_function',
              'doctest of stpackage.a_failing_function'),
             ('FAIL','ERROR',)),
            (('Doctest: stpackage.a_function',
              'doctest of stpackage.a_function'),
             ('ok',)),
            (('Doctest: stpackage.subpak.more.deep_doc',
              'doctest of stpackage.subpak.more.deep_doc'),
             ('ok',)),
            (('/test-dir: test.test',),
             ('ok',)),
            (('/test-dir: test.test_that_fails_too',),
             ('FAIL',)),
            (('/test-dir: test_module.test',),
             ('ok',)),
            (('/stpackage/test-dir: tests.test',),
             ('ok',)),
            (('/stpackage/subpak/other/tests: tests.test',),
             ('ok',)),
            (('testFailUnless (test_interp_assert.FunkyColdMedina)',),
             ('FAIL',)),
            (('/test_failure: test_interp_assert.test_simple_assert',),
             ('FAIL',)),
            (('/test_failure: test_interp_assert.test_assert_expression',),
            ('FAIL',)),
            (('/test_failure: test_interp_assert.test_raise_assert',),
             ('FAIL',)),
            (('/test_failure: test_interp_assert.test_unicode_assert',),
             ('FAIL',)),
            (('/test_failure: test_interp_assert.test_unicode_in_junk',),
             ('FAIL',)),
            (('tests.test_basic.TestClassWithLabel.test_method',),
             ('ok',)),
            (('(tests.test_basic.TestSomething) '
              '"a test method in a test class"',),
             ('ok',)),
            (('tests.test_basic.TestSomething.test_method_two',),
             ('ok',)),
            (('tests.test_basic.test_basic',),
             ('ok',)),
            (('test_nothing (tests.test_capture.Capturer)',),
             ('FAIL',)),
            (('tests.test_capture.test_that_fails',),
             ('FAIL',)),
            (('testCapture (tests.test_unittest.TestBasic)',),
             ('FAIL',)),
            (('testPasses (tests.test_unittest.TestBasic)',),
             ('ok',)),
            (('tests.test_module_fixtures.test',),
             ('ok',)),
            (('tests.test_with_setup.test_with_setup',),
             ('ok',)),
            (('tests.test_with_setup.test_post_with_setup',),
             ('ok',)),
            (('tests.test_with_setup.test_atomic_with_setup',),
             ('FAIL',)),
            (('tests.test_with_setup.test_post_atomic_with_setup',),
             ('ok',)),
            (('testme.test_me_once',),('ok',))
             )
        res = re.compile(r'^(?:/.*?/st)?(.*?) \.\.\. (\w+)$',re.MULTILINE)
        res_matches = res.findall(results)
        self.failUnless(res_matches,'No result lines found in results')
        for m in res_matches:
            expected = None
            for test_names, results in expect:
                if m[0] in test_names:
                    expected = results
                    break
            if expected is None:
                self.fail("Unknown test '%s' (result: %s)" % (m[0],m[1]))
            self.failUnless(m[1] in expected,
                            'Wrong result for test %s: expected %s, got %s'
                            % (m[0],expected,m[1]))
        self.assertEqual(len(expect),len(res_matches),
                         'Expected to find results for %d tests, got %s'
                         % (len(expect),len(res_matches)))

    def test03_OutputCapture(self):
        """Expected output capture found"""
        results = self.results.read()
        capt = re.compile(
            r'={70}\n'
            r'(?:FAIL|ERROR): (?P<test>.*?)\n'
            r'-{70}\n'
            r'.*?assert ExpectedFail(?:, "(?P<expect>[^"]+)").*?'
            r'>> begin captured stdout << '
            r'---------------------\n'
            r'(?P<found>.*?)\n'
            r'--------------------- '
            r'>> end captured stdout <<',re.DOTALL)

        count = 0
        for match in capt.finditer(results):
            m = match.groupdict({})
            # the found part always has a trailing newline
            found = m.get('found','').rstrip()
            # replace literal newlines into expect
            expect = m.get('expect','').replace(r'\n','\n')
            self.assertEqual(expect,found,
                             "Expected output '%s', got '%s' for test %s"
                             % (expect,found,
                                m.get('test')))
            count += 1
        self.assertEqual(count,3,"Expected %d output captures, got %d"
                         % (3, count))
        
    def test04_AssertInspection(self):
        """Expected assert inspection output found"""

        results = self.results.read()
        expect = [
            ('assert False, "assert False"',
             '>>  assert False, "assert False"'),
            ('assert a == 4, "assert 2 is 4"',
             '>>  assert 2 == 4, "assert 2 is 4"'),
            ('if not b == \'foo\': raise AssertionError, "a message"',
             ">>  if not ['1', '2', '3'] == 'foo': raise AssertionError, "
             '"a message"'),
            ("assert ublob.has_key('b'), 'No b in blob'",
             r">>  assert {'a': [u'Andr\x82 3000', 200], "
             r"u'\xa0dre': 'stuff'}.has_key('b'), 'No b in blob'")]

        pos = 0
        for orig, inspected in expect:
            pos = results.find(orig,pos)
            self.failUnless(pos > 0,
                            "Failed to find assert '%s' in results" % orig)
            pos = results.find(inspected,pos)
            self.failUnless(pos > 0,
                            "Failed to find inspected assert '%s' in results"
                            % inspected)
        
def local_file(filename):
    # FIXME use pkg_resources?
    here = os.path.dirname(__file__)
    return os.path.join(here,filename)

def run_nose():
    tmp = sys.stderr
    sys.stderr = log = file(local_file('selftest.log'),'w')
    stream = file(local_file('selftest.result'),'w')

    import nose
    import nose.exception
    nose.main(argv=['-d','-vvvvvv','-w','st'],stream=stream)    

    nose.Capture.end()
    nose.exception.remove()    
    log.close()
    stream.close()         
    sys.stderr = tmp

ExpectedFail = False
    
def suite():
    run_nose()    
    suite = unittest.makeSuite(TestNose)
    return suite

if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=2).run(suite())
    if not result.wasSuccessful():
        sys.stderr.write(">> check selftest.result for test run output and\n"
                         "   selftest.log for test discovery log\n")
        sys.exit(1)
    sys.exit(0)
