import os
import tempfile

special_file_name = os.path.join(tempfile.gettempdir(), 'cheesecake_special')

# Just create the file.
fd = open(special_file_name, 'w')
fd.close()

